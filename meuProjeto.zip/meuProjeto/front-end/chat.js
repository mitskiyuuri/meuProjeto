const API = "http://localhost:3000";

const token = localStorage.getItem("token");
const usuario = JSON.parse(
    localStorage.getItem("usuario") || "{}"
);

const params =
    new URLSearchParams(
        window.location.search
    );

const conversaId =
    params.get("id") || "1";

const mensagensContainer =
    document.getElementById(
        "mensagens"
    );

const formMensagem =
    document.getElementById(
        "formMensagem"
    );

const campoMensagem =
    document.getElementById(
        "campoMensagem"
    );

const statusSocket =
    document.getElementById(
        "statusSocket"
    );

const numeroConversa =
    document.getElementById(
        "numeroConversa"
    );

numeroConversa.textContent =
    conversaId;

// ==========================================
// LOGIN
// ==========================================

if (!token) {
    alert(
        "Faça login para acessar o chat."
    );

    window.location.href =
        "login.html";
}

// ==========================================
// ESCAPAR TEXTO
// ==========================================

function escaparTexto(
    texto
) {
    return String(
        texto || ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}

// ==========================================
// ADICIONAR MENSAGEM
// ==========================================

function adicionarMensagem(
    mensagem
) {

    const div =
        document.createElement(
            "div"
        );

    const minhaMensagem =
        String(
            mensagem.remetente_id
        ) ===
        String(usuario.id);

    div.style.marginBottom =
        "15px";

    div.style.padding =
        "10px";

    div.style.border =
        "1px solid #ccc";

    if (minhaMensagem) {

        div.innerHTML = `
            <strong>Você</strong>

            <p>
                ${escaparTexto(
                    mensagem.mensagem
                )}
            </p>
        `;

    } else {

        div.innerHTML = `
            <strong>
                ${escaparTexto(
                    mensagem.nome_remetente ||
                    "Outro usuário"
                )}
            </strong>

            <p>
                ${escaparTexto(
                    mensagem.mensagem
                )}
            </p>
        `;
    }

    mensagensContainer.appendChild(
        div
    );

    mensagensContainer.scrollTop =
        mensagensContainer.scrollHeight;
}

// ==========================================
// HISTÓRICO
// ==========================================

async function carregarMensagens() {

    try {

        const resposta =
            await fetch(
                `${API}/conversas/${conversaId}/mensagens`,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );

        const dados =
            await resposta.json();

        if (!resposta.ok) {
            throw new Error(
                dados.mensagem ||
                "Erro ao carregar mensagens."
            );
        }

        mensagensContainer.innerHTML =
            "";

        if (
            dados.length ===
            0
        ) {

            mensagensContainer.innerHTML =
                "<p>Nenhuma mensagem ainda.</p>";

            return;
        }

        dados.forEach(
            mensagem => {
                adicionarMensagem(
                    mensagem
                );
            }
        );

    } catch (erro) {

        mensagensContainer.innerHTML = `
            <p style="color:red;">
                ${escaparTexto(
                    erro.message
                )}
            </p>
        `;
    }
}

// ==========================================
// MARCAR COMO LIDAS
// ==========================================

async function marcarComoLidas() {

    try {

        await fetch(
            `${API}/conversas/${conversaId}/mensagens/lidas`,
            {
                method: "PUT",

                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );

    } catch (erro) {

        console.error(
            "Erro ao marcar mensagens como lidas:",
            erro
        );
    }
}

// ==========================================
// SOCKET.IO
// ==========================================

const socket =
    io(API, {
        auth: {
            token: token
        }
    });

socket.on(
    "connect",
    () => {

        statusSocket.textContent =
            "✅ Chat conectado em tempo real.";

        socket.emit(
            "entrar_conversa",
            conversaId
        );
    }
);

socket.on(
    "entrou_conversa",
    (dados) => {

        console.log(
            `Entrou na conversa ${dados.conversaId}`
        );
    }
);

socket.on(
    "connect_error",
    (erro) => {

        statusSocket.textContent =
            "❌ Erro ao conectar ao chat.";

        console.error(
            "Erro Socket.io:",
            erro.message
        );
    }
);

socket.on(
    "erro_conversa",
    (dados) => {

        statusSocket.textContent =
            "❌ Você não pode acessar esta conversa.";

        console.error(
            dados.mensagem
        );
    }
);

socket.on(
    "disconnect",
    () => {

        statusSocket.textContent =
            "❌ Chat desconectado.";
    }
);

// ==========================================
// NOVA MENSAGEM
// ==========================================

socket.on(
    "nova_mensagem",
    (mensagem) => {

        adicionarMensagem(
            mensagem
        );

        if (
            String(
                mensagem.remetente_id
            ) !==
            String(usuario.id)
        ) {
            marcarComoLidas();
        }
    }
);

// ==========================================
// ENVIAR MENSAGEM
// ==========================================

formMensagem.addEventListener(
    "submit",
    async (evento) => {

        evento.preventDefault();

        const mensagem =
            campoMensagem.value.trim();

        if (!mensagem) {
            return;
        }

        try {

            const resposta =
                await fetch(
                    `${API}/conversas/${conversaId}/mensagens`,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${token}`
                        },

                        body: JSON.stringify({
                            mensagem
                        })
                    }
                );

            const dados =
                await resposta.json();

            if (!resposta.ok) {
                throw new Error(
                    dados.mensagem ||
                    "Erro ao enviar mensagem."
                );
            }

            campoMensagem.value =
                "";

            campoMensagem.focus();

        } catch (erro) {

            alert(
                erro.message
            );
        }
    }
);

// ==========================================
// INICIAR CHAT
// ==========================================

async function iniciarChat() {

    await carregarMensagens();

    await marcarComoLidas();
}

iniciarChat();