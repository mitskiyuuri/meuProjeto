const express = require("express");
const router = express.Router();

const userController = require("../controllers/userController");
const verificarToken = require("../middleware/auth");

// ==========================================
// ROTAS PÚBLICAS
// ==========================================

router.post(
    "/cadastro",
    userController.cadastrarUsuario
);

router.post(
    "/login",
    userController.loginUsuario
);

// Recuperação de senha
router.post(
    "/recuperar-senha",
    userController.solicitarRecuperacao
);

router.post(
    "/redefinir-senha",
    userController.redefinirSenha
);

// ==========================================
// ROTAS PROTEGIDAS
// ==========================================

router.get(
    "/perfil",
    verificarToken,
    userController.buscarPerfil
);

router.put(
    "/perfil",
    verificarToken,
    userController.atualizarPerfil
);

router.delete(
    "/perfil",
    verificarToken,
    userController.excluirPerfil
);

module.exports = router;