const express = require("express");
const router = express.Router();

const denunciaController = require("../controllers/denunciaController");
const verificarToken = require("../middleware/auth");

router.use(verificarToken);

// Criar denúncia
router.post("/", denunciaController.criar);

module.exports = router;