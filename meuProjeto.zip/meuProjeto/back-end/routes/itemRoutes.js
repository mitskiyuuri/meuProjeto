const express = require("express");
const router = express.Router();

const itemController = require("../controllers/itemController");
const verificarToken = require("../middleware/auth");
const upload = require("../middleware/upload");

// Rotas públicas
router.get(
    "/categorias",
    itemController.listarCategorias
);

router.get(
    "/",
    itemController.listarItens
);

router.get(
    "/:id",
    itemController.buscarItem
);

// Rotas protegidas
router.post(
    "/",
    verificarToken,
    upload.array("imagem", 5),
    itemController.criarItem
);

router.put(
    "/:id",
    verificarToken,
    itemController.atualizarItem
);

router.put(
    "/:id/status",
    verificarToken,
    itemController.atualizarStatus
);

router.delete(
    "/:id",
    verificarToken,
    itemController.excluirItem
);

module.exports = router;