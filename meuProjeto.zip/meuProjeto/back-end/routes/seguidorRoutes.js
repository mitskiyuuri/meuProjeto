const express = require("express");
const router = express.Router();

const seguidorController = require("../controllers/seguidorController");
const verificarToken = require("../middleware/auth");

router.use(verificarToken);

// Seguir
router.post("/:id", seguidorController.seguir);

// Deixar de seguir
router.delete("/:id", seguidorController.deixarDeSeguir);

// Listar seguidores de um usuário
router.get("/:id/seguidores", seguidorController.listarSeguidores);

// Listar quem um usuário segue
router.get("/:id/seguindo", seguidorController.listarSeguindo);

module.exports = router;