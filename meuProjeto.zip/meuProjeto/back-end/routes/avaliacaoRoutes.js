const express = require("express");
const router = express.Router();

const avaliacaoController = require("../controllers/avaliacaoController");
const verificarToken = require("../middleware/auth");

router.use(verificarToken);

// Criar avaliação
router.post("/", avaliacaoController.criar);

// Listar avaliações de um usuário
router.get("/usuario/:id", avaliacaoController.listarPorUsuario);

module.exports = router;