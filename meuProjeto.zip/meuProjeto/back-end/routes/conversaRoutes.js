const express = require("express");
const router = express.Router();

const conversaController =
    require("../controllers/conversaController");

const verificarToken =
    require("../middleware/auth");

router.use(verificarToken);

// Criar conversa a partir de uma solicitação aceita
router.post(
    "/solicitacao/:id",
    conversaController.criarConversa
);

// Listar conversas do usuário
router.get(
    "/minhas",
    conversaController.listarMinhasConversas
);

module.exports = router;