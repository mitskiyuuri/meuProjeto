const express = require("express");
const router = express.Router();

const mensagemController = require("../controllers/mensagemController");
const verificarToken = require("../middleware/auth");

// Todas as rotas precisam de login
router.use(verificarToken);

// Enviar mensagem
router.post("/:id/mensagens", mensagemController.enviarMensagem);

// Listar histórico
router.get("/:id/mensagens", mensagemController.listarMensagens);

// Marcar mensagens como lidas
router.put("/:id/mensagens/lidas", mensagemController.marcarComoLidas);

module.exports = router;