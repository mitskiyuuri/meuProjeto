const db = require("../config/database");

// Verificar se o usuário existe
function verificarUsuario(id, callback) {
    const sql = `
        SELECT id
        FROM usuarios
        WHERE id = ?
    `;

    db.query(sql, [id], callback);
}

// Verificar se o item existe
function verificarItem(id, callback) {
    const sql = `
        SELECT id
        FROM itens
        WHERE id = ?
    `;

    db.query(sql, [id], callback);
}

// Verificar se o comentário existe
function verificarComentario(id, callback) {
    const sql = `
        SELECT id
        FROM comentarios
        WHERE id = ?
    `;

    db.query(sql, [id], callback);
}

// Criar denúncia
function criar(denuncia, callback) {
    const sql = `
        INSERT INTO denuncias
        (usuario_id, tipo, tipo_referencia, referencia_id, motivo)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.query(
        sql,
        [
            denuncia.usuario_id,
            denuncia.tipo,
            denuncia.tipo_referencia,
            denuncia.referencia_id,
            denuncia.motivo
        ],
        callback
    );
}

module.exports = {
    verificarUsuario,
    verificarItem,
    verificarComentario,
    criar
};