const db = require("../config/database");

// ==========================================
// CADASTRO
// ==========================================

function criarUsuario(usuario, callback) {
    const sql = `
        INSERT INTO usuarios
        (nome, email, telefone, cpf, senha, cep, cidade, estado, bairro, endereco, numero, complemento, foto_perfil, foto_documento)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, [
        usuario.nome,
        usuario.email,
        usuario.telefone,
        usuario.cpf,
        usuario.senha,
        usuario.cep,
        usuario.cidade,
        usuario.estado,
        usuario.bairro,
        usuario.endereco,
        usuario.numero,
        usuario.complemento,
        usuario.foto_perfil,
        usuario.foto_documento
    ], callback);
}

function buscarPorEmailOuCpf(email, cpf, callback) {
    const sql = `
        SELECT *
        FROM usuarios
        WHERE email = ? OR cpf = ?
    `;

    db.query(sql, [email, cpf], callback);
}

function buscarPorEmail(email, callback) {
    const sql = `
        SELECT *
        FROM usuarios
        WHERE email = ?
    `;

    db.query(sql, [email], callback);
}

function buscarPorId(id, callback) {
    const sql = `
        SELECT
            id,
            nome,
            email,
            telefone,
            cpf,
            cep,
            cidade,
            estado,
            bairro,
            endereco,
            numero,
            complemento,
            foto_perfil
        FROM usuarios
        WHERE id = ?
    `;

    db.query(sql, [id], callback);
}

// ==========================================
// MÉDIA DAS AVALIAÇÕES
// ==========================================

function buscarMediaAvaliacoes(usuarioId, callback) {
    const sql = `
        SELECT
            IFNULL(ROUND(AVG(nota), 1), 0) AS media_avaliacoes,
            COUNT(*) AS total_avaliacoes
        FROM avaliacoes
        WHERE avaliado_id = ?
    `;

    db.query(
        sql,
        [usuarioId],
        callback
    );
}

// ==========================================
// EDITAR PERFIL
// ==========================================

function atualizarUsuario(usuario, callback) {
    const sql = `
        UPDATE usuarios
        SET
            nome = ?,
            telefone = ?,
            cep = ?,
            cidade = ?,
            estado = ?,
            bairro = ?,
            endereco = ?,
            numero = ?,
            complemento = ?
        WHERE id = ?
    `;

    db.query(sql, [
        usuario.nome,
        usuario.telefone,
        usuario.cep,
        usuario.cidade,
        usuario.estado,
        usuario.bairro,
        usuario.endereco,
        usuario.numero,
        usuario.complemento,
        usuario.id
    ], callback);
}

// ==========================================
// EXCLUIR PERFIL
// ==========================================

function excluirUsuario(id, callback) {
    const sql = `
        DELETE FROM usuarios
        WHERE id = ?
    `;

    db.query(sql, [id], callback);
}

// ==========================================
// RECUPERAÇÃO DE SENHA
// ==========================================

function buscarUsuarioParaRecuperacao(email, callback) {
    const sql = `
        SELECT id, email
        FROM usuarios
        WHERE email = ?
    `;

    db.query(
        sql,
        [email],
        callback
    );
}

function criarRecuperacao(usuarioId, codigoHash, callback) {
    const sql = `
        INSERT INTO recuperacoes_senha
        (usuario_id, codigo_hash, expira_em)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))
    `;

    db.query(
        sql,
        [usuarioId, codigoHash],
        callback
    );
}

function buscarRecuperacao(
    usuarioId,
    codigoHash,
    callback
) {
    const sql = `
        SELECT *
        FROM recuperacoes_senha
        WHERE usuario_id = ?
        AND codigo_hash = ?
        AND usado = FALSE
        AND expira_em > NOW()
        ORDER BY id DESC
        LIMIT 1
    `;

    db.query(
        sql,
        [usuarioId, codigoHash],
        callback
    );
}

function marcarRecuperacaoComoUsada(
    id,
    callback
) {
    const sql = `
        UPDATE recuperacoes_senha
        SET usado = TRUE
        WHERE id = ?
    `;

    db.query(
        sql,
        [id],
        callback
    );
}

function atualizarSenha(
    id,
    senha,
    callback
) {
    const sql = `
        UPDATE usuarios
        SET senha = ?
        WHERE id = ?
    `;

    db.query(
        sql,
        [senha, id],
        callback
    );
}

module.exports = {
    criarUsuario,
    buscarPorEmailOuCpf,
    buscarPorEmail,
    buscarPorId,
    buscarMediaAvaliacoes,
    atualizarUsuario,
    excluirUsuario,
    buscarUsuarioParaRecuperacao,
    criarRecuperacao,
    buscarRecuperacao,
    marcarRecuperacaoComoUsada,
    atualizarSenha
};