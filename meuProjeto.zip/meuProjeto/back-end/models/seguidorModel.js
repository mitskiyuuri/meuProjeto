const db = require("../config/database");

// Verificar se o usuário existe
function buscarUsuario(id, callback) {
    const sql = `
        SELECT id, nome
        FROM usuarios
        WHERE id = ?
    `;

    db.query(sql, [id], callback);
}

// Verificar se já está seguindo
function verificarSeguimento(seguidorId, seguidoId, callback) {
    const sql = `
        SELECT id
        FROM seguidores
        WHERE seguidor_id = ?
        AND seguido_id = ?
    `;

    db.query(
        sql,
        [seguidorId, seguidoId],
        callback
    );
}

// Seguir usuário
function seguir(seguidorId, seguidoId, callback) {
    const sql = `
        INSERT INTO seguidores
        (seguidor_id, seguido_id)
        VALUES (?, ?)
    `;

    db.query(
        sql,
        [seguidorId, seguidoId],
        callback
    );
}

// Deixar de seguir
function deixarDeSeguir(seguidorId, seguidoId, callback) {
    const sql = `
        DELETE FROM seguidores
        WHERE seguidor_id = ?
        AND seguido_id = ?
    `;

    db.query(
        sql,
        [seguidorId, seguidoId],
        callback
    );
}

// Listar seguidores
function listarSeguidores(usuarioId, callback) {
    const sql = `
        SELECT
            u.id,
            u.nome,
            u.foto_perfil
        FROM seguidores s
        JOIN usuarios u
            ON s.seguidor_id = u.id
        WHERE s.seguido_id = ?
        ORDER BY s.id DESC
    `;

    db.query(sql, [usuarioId], callback);
}

// Listar quem o usuário segue
function listarSeguindo(usuarioId, callback) {
    const sql = `
        SELECT
            u.id,
            u.nome,
            u.foto_perfil
        FROM seguidores s
        JOIN usuarios u
            ON s.seguido_id = u.id
        WHERE s.seguidor_id = ?
        ORDER BY s.id DESC
    `;

    db.query(sql, [usuarioId], callback);
}

module.exports = {
    buscarUsuario,
    verificarSeguimento,
    seguir,
    deixarDeSeguir,
    listarSeguidores,
    listarSeguindo
};