const db = require("../config/database");

// Verificar se o usuário avaliado existe
function buscarUsuario(avaliadoId, callback) {
    const sql = `
        SELECT id, nome
        FROM usuarios
        WHERE id = ?
    `;

    db.query(sql, [avaliadoId], callback);
}

// Verificar se já existe avaliação
function verificarAvaliacao(avaliadorId, avaliadoId, callback) {
    const sql = `
        SELECT id
        FROM avaliacoes
        WHERE avaliador_id = ? AND avaliado_id = ?
    `;

    db.query(
        sql,
        [avaliadorId, avaliadoId],
        callback
    );
}

// Criar avaliação
function criar(avaliacao, callback) {
    const sql = `
        INSERT INTO avaliacoes
        (avaliador_id, avaliado_id, nota, comentario)
        VALUES (?, ?, ?, ?)
    `;

    db.query(
        sql,
        [
            avaliacao.avaliador_id,
            avaliacao.avaliado_id,
            avaliacao.nota,
            avaliacao.comentario
        ],
        callback
    );
}

// Listar avaliações recebidas por um usuário
function listarPorUsuario(usuarioId, callback) {
    const sql = `
        SELECT
            a.id,
            a.avaliador_id,
            a.avaliado_id,
            a.nota,
            a.comentario,
            a.data,
            u.nome AS nome_avaliador
        FROM avaliacoes a
        JOIN usuarios u ON a.avaliador_id = u.id
        WHERE a.avaliado_id = ?
        ORDER BY a.id DESC
    `;

    db.query(sql, [usuarioId], callback);
}

module.exports = {
    buscarUsuario,
    verificarAvaliacao,
    criar,
    listarPorUsuario
};