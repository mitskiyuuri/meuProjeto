const db = require("../config/database");

// Verifica se o usuário participa da conversa
function verificarParticipante(conversaId, usuarioId, callback) {
    const sql = `
        SELECT *
        FROM conversas
        WHERE id = ?
        AND (doador_id = ? OR interessado_id = ?)
    `;

    db.query(
        sql,
        [conversaId, usuarioId, usuarioId],
        callback
    );
}

// Criar mensagem
function criarMensagem(conversaId, remetenteId, mensagem, callback) {
    const sql = `
        INSERT INTO mensagens
        (conversa_id, remetente_id, mensagem)
        VALUES (?, ?, ?)
    `;

    db.query(
        sql,
        [conversaId, remetenteId, mensagem],
        callback
    );
}

// Listar histórico da conversa
function listarMensagens(conversaId, callback) {
    const sql = `
        SELECT
            m.id,
            m.conversa_id,
            m.remetente_id,
            m.mensagem,
            m.lida,
            m.enviada_em,
            u.nome AS nome_remetente
        FROM mensagens m
        JOIN usuarios u ON m.remetente_id = u.id
        WHERE m.conversa_id = ?
        ORDER BY m.id ASC
    `;

    db.query(sql, [conversaId], callback);
}

// Marcar mensagens recebidas como lidas
function marcarComoLidas(conversaId, usuarioId, callback) {
    const sql = `
        UPDATE mensagens
        SET lida = 1
        WHERE conversa_id = ?
        AND remetente_id <> ?
    `;

    db.query(
        sql,
        [conversaId, usuarioId],
        callback
    );
}

module.exports = {
    verificarParticipante,
    criarMensagem,
    listarMensagens,
    marcarComoLidas
};