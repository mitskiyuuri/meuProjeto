const db = require("../config/database");

// Buscar solicitação e descobrir os participantes
function buscarSolicitacao(solicitacaoId, usuarioId, callback) {
    const sql = `
        SELECT
            s.id,
            s.item_id,
            s.usuario_id AS interessado_id,
            s.status,
            i.usuario_id AS doador_id
        FROM solicitacoes s
        JOIN itens i ON s.item_id = i.id
        WHERE s.id = ?
        AND (s.usuario_id = ? OR i.usuario_id = ?)
    `;

    db.query(
        sql,
        [solicitacaoId, usuarioId, usuarioId],
        callback
    );
}

// Verificar se a conversa já existe
function buscarConversa(itemId, doadorId, interessadoId, callback) {
    const sql = `
        SELECT
            c.id,
            c.item_id,
            c.doador_id,
            c.interessado_id
        FROM conversas c
        WHERE c.item_id = ?
        AND c.doador_id = ?
        AND c.interessado_id = ?
        LIMIT 1
    `;

    db.query(
        sql,
        [itemId, doadorId, interessadoId],
        callback
    );
}

// Criar conversa
function criarConversa(itemId, doadorId, interessadoId, callback) {
    const sql = `
        INSERT INTO conversas
        (item_id, doador_id, interessado_id)
        VALUES (?, ?, ?)
    `;

    db.query(
        sql,
        [itemId, doadorId, interessadoId],
        callback
    );
}

// Verificar se o usuário participa da conversa
function verificarParticipante(conversaId, usuarioId, callback) {
    const sql = `
        SELECT
            id,
            doador_id,
            interessado_id
        FROM conversas
        WHERE id = ?
        AND (doador_id = ? OR interessado_id = ?)
    `;

    db.query(
        sql,
        [conversaId, usuarioId, usuarioId],
        callback
    );
}

// Listar conversas do usuário
function listarMinhasConversas(usuarioId, callback) {
    const sql = `
        SELECT
            c.id,
            c.item_id,
            i.titulo AS item_titulo,

            CASE
                WHEN c.doador_id = ?
                THEN c.interessado_id
                ELSE c.doador_id
            END AS outro_usuario_id,

            CASE
                WHEN c.doador_id = ?
                THEN ui.nome
                ELSE ud.nome
            END AS outro_usuario_nome,

            (
                SELECT m.mensagem
                FROM mensagens m
                WHERE m.conversa_id = c.id
                ORDER BY m.id DESC
                LIMIT 1
            ) AS ultima_mensagem,

            (
                SELECT COUNT(*)
                FROM mensagens m
                WHERE m.conversa_id = c.id
                AND m.remetente_id <> ?
                AND m.lida = 0
            ) AS mensagens_nao_lidas

        FROM conversas c

        JOIN itens i
            ON c.item_id = i.id

        JOIN usuarios ud
            ON c.doador_id = ud.id

        JOIN usuarios ui
            ON c.interessado_id = ui.id

        WHERE c.doador_id = ?
        OR c.interessado_id = ?

        ORDER BY c.id DESC
    `;

    db.query(
        sql,
        [
            usuarioId,
            usuarioId,
            usuarioId,
            usuarioId,
            usuarioId
        ],
        callback
    );
}

module.exports = {
    buscarSolicitacao,
    buscarConversa,
    criarConversa,
    verificarParticipante,
    listarMinhasConversas
};