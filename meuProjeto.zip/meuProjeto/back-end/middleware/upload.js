const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Pasta onde as imagens serão salvas
const pastaUploads = path.join(__dirname, "..", "uploads");

// Cria a pasta se ela ainda não existir
if (!fs.existsSync(pastaUploads)) {
    fs.mkdirSync(pastaUploads, {
        recursive: true
    });
}

// Configuração do armazenamento
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, pastaUploads);
    },

    filename: (req, file, cb) => {
        const sufixoUnico =
            Date.now() +
            "-" +
            Math.round(Math.random() * 1e9);

        const extensao =
            path.extname(file.originalname).toLowerCase();

        cb(
            null,
            `${file.fieldname}-${sufixoUnico}${extensao}`
        );
    }
});

// Tipos permitidos
const extensoesPermitidas = [
    ".jpg",
    ".jpeg",
    ".png",
    ".webp"
];

const mimeTypesPermitidos = [
    "image/jpeg",
    "image/png",
    "image/webp"
];

// Filtro de segurança
const fileFilter = (req, file, cb) => {
    const extensao =
        path.extname(file.originalname).toLowerCase();

    const extensaoValida =
        extensoesPermitidas.includes(extensao);

    const mimeValido =
        mimeTypesPermitidos.includes(file.mimetype);

    if (extensaoValida && mimeValido) {
        return cb(null, true);
    }

    return cb(
        new Error(
            "Apenas imagens JPG, JPEG, PNG e WEBP são permitidas."
        ),
        false
    );
};

const upload = multer({
    storage,

    limits: {
        fileSize: 5 * 1024 * 1024,
        files: 5
    },

    fileFilter
});

module.exports = upload;