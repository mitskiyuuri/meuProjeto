const jwt = require("jsonwebtoken");

function verificarToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({
            mensagem: "Acesso negado. Token não informado."
        });
    }

    const partes = authHeader.split(" ");

    if (
        partes.length !== 2 ||
        partes[0] !== "Bearer" ||
        !partes[1]
    ) {
        return res.status(401).json({
            mensagem: "Formato de Token inválido. Use o formato: Bearer <token>"
        });
    }

    const token = partes[1];
    const secretKey = process.env.JWT_SECRET;

    if (!secretKey) {
        console.error(
            "JWT_SECRET não foi configurado no arquivo .env"
        );

        return res.status(500).json({
            mensagem: "Configuração de segurança do servidor não encontrada."
        });
    }

    try {
        const decoded = jwt.verify(
            token,
            secretKey
        );

        req.usuario = decoded;

        next();

    } catch (erro) {
        console.error(
            "Erro na verificação do token:",
            erro.message
        );

        return res.status(401).json({
            mensagem: "Token inválido ou expirado."
        });
    }
}

module.exports = verificarToken;