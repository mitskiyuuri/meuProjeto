const express = require("express");
const cors = require("cors");
const path = require("path");
const http = require("http");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");

require("dotenv").config({
    path: path.join(__dirname, ".env")
});

require("./config/database");

const conversaModel =
    require("./models/conversaModel");

const app = express();
const server = http.createServer(app);

// ==========================================
// SOCKET.IO
// ==========================================

const io = new Server(server, {
    cors: {
        origin: "*"
    }
});

app.set("io", io);

// Verificar token do Socket.io
io.use((socket, next) => {
    const token =
        socket.handshake.auth &&
        socket.handshake.auth.token;

    if (!token) {
        return next(
            new Error("Token não informado.")
        );
    }

    const secretKey =
        process.env.JWT_SECRET;

    if (!secretKey) {
        return next(
            new Error(
                "JWT_SECRET não configurado."
            )
        );
    }

    try {
        const usuario =
            jwt.verify(
                token,
                secretKey
            );

        socket.usuario =
            usuario;

        next();

    } catch (erro) {

        next(
            new Error(
                "Token inválido ou expirado."
            )
        );
    }
});

// Conexão
io.on("connection", (socket) => {

    console.log(
        `🔌 Usuário ${socket.usuario.id} conectado ao Socket.io`
    );

    socket.on(
        "entrar_conversa",
        (conversaId) => {

            const id =
                Number(conversaId);

            if (!id) {
                socket.emit(
                    "erro_conversa",
                    {
                        mensagem:
                            "Conversa inválida."
                    }
                );

                return;
            }

            conversaModel.verificarParticipante(
                id,
                socket.usuario.id,
                (err, resultados) => {

                    if (err) {
                        console.error(
                            "Erro ao verificar participante do Socket.io:",
                            err
                        );

                        socket.emit(
                            "erro_conversa",
                            {
                                mensagem:
                                    "Erro ao verificar conversa."
                            }
                        );

                        return;
                    }

                    if (
                        !resultados ||
                        resultados.length === 0
                    ) {
                        socket.emit(
                            "erro_conversa",
                            {
                                mensagem:
                                    "Você não participa desta conversa."
                            }
                        );

                        return;
                    }

                    socket.join(
                        `conversa_${id}`
                    );

                    console.log(
                        `Usuário ${socket.usuario.id} entrou na conversa ${id}`
                    );

                    socket.emit(
                        "entrou_conversa",
                        {
                            conversaId: id
                        }
                    );
                }
            );
        }
    );

    socket.on(
        "disconnect",
        () => {

            console.log(
                `🔌 Usuário ${socket.usuario.id} desconectado do Socket.io`
            );
        }
    );
});

// ==========================================
// MIDDLEWARES
// ==========================================

app.use(cors());
app.use(express.json());
app.use(
    express.urlencoded({
        extended: true
    })
);

// Imagens
app.use(
    "/uploads",
    express.static(
        path.join(
            __dirname,
            "uploads"
        )
    )
);

// ==========================================
// ROTAS
// ==========================================

const userRoutes =
    require("./routes/userRoutes");

const itemRoutes =
    require("./routes/itemRoutes");

const solicitacaoRoutes =
    require("./routes/solicitacaoRoutes");

const comentarioRoutes =
    require("./routes/comentarioRoutes");

const conversaRoutes =
    require("./routes/conversaRoutes");

const mensagemRoutes =
    require("./routes/mensagemRoutes");

const avaliacaoRoutes =
    require("./routes/avaliacaoRoutes");

const denunciaRoutes =
    require("./routes/denunciaRoutes");

const seguidorRoutes =
    require("./routes/seguidorRoutes");

app.use(
    "/usuarios",
    userRoutes
);

app.use(
    "/itens",
    itemRoutes
);

app.use(
    "/solicitacoes",
    solicitacaoRoutes
);

app.use(
    "/comentarios",
    comentarioRoutes
);

app.use(
    "/conversas",
    conversaRoutes
);

app.use(
    "/conversas",
    mensagemRoutes
);

app.use(
    "/avaliacoes",
    avaliacaoRoutes
);

app.use(
    "/denuncias",
    denunciaRoutes
);

app.use(
    "/seguidores",
    seguidorRoutes
);

// ==========================================
// ROTA DE TESTE
// ==========================================

app.get(
    "/",
    (req, res) => {
        res.send(
            "Servidor funcionando!"
        );
    }
);

// ==========================================
// INICIAR SERVIDOR
// ==========================================

const PORT =
    process.env.PORT || 3000;

server.listen(
    PORT,
    () => {

        console.log(
            `🚀 Servidor iniciado e rodando na porta ${PORT}!`
        );
    }
);