const seguidorModel = require("../models/seguidorModel");

// Seguir usuário
exports.seguir = (req, res) => {
    const seguidorId = req.usuario.id;
    const seguidoId = Number(req.params.id);

    if (!seguidoId) {
        return res.status(400).json({
            mensagem: "Usuário inválido."
        });
    }

    if (seguidorId === seguidoId) {
        return res.status(400).json({
            mensagem: "Você não pode seguir a si mesmo."
        });
    }

    seguidorModel.buscarUsuario(
        seguidoId,
        (err, usuarios) => {
            if (err) {
                console.error(
                    "Erro ao buscar usuário:",
                    err
                );

                return res.status(500).json({
                    mensagem: "Erro ao buscar usuário."
                });
            }

            if (
                !usuarios ||
                usuarios.length === 0
            ) {
                return res.status(404).json({
                    mensagem: "Usuário não encontrado."
                });
            }

            seguidorModel.verificarSeguimento(
                seguidorId,
                seguidoId,
                (err, resultados) => {
                    if (err) {
                        console.error(
                            "Erro ao verificar seguimento:",
                            err
                        );

                        return res.status(500).json({
                            mensagem:
                                "Erro ao verificar seguimento."
                        });
                    }

                    if (
                        resultados &&
                        resultados.length > 0
                    ) {
                        return res.status(400).json({
                            mensagem:
                                "Você já segue este usuário."
                        });
                    }

                    seguidorModel.seguir(
                        seguidorId,
                        seguidoId,
                        (err, result) => {
                            if (err) {
                                console.error(
                                    "Erro ao seguir usuário:",
                                    err
                                );

                                return res.status(500).json({
                                    mensagem:
                                        "Erro ao seguir usuário."
                                });
                            }

                            return res.status(201).json({
                                mensagem:
                                    "Usuário seguido com sucesso!"
                            });
                        }
                    );
                }
            );
        }
    );
};

// Deixar de seguir
exports.deixarDeSeguir = (req, res) => {
    const seguidorId = req.usuario.id;
    const seguidoId = Number(req.params.id);

    if (!seguidoId) {
        return res.status(400).json({
            mensagem: "Usuário inválido."
        });
    }

    seguidorModel.deixarDeSeguir(
        seguidorId,
        seguidoId,
        (err, result) => {
            if (err) {
                console.error(
                    "Erro ao deixar de seguir:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao deixar de seguir."
                });
            }

            if (
                !result ||
                result.affectedRows === 0
            ) {
                return res.status(404).json({
                    mensagem:
                        "Você não segue este usuário."
                });
            }

            return res.status(200).json({
                mensagem:
                    "Usuário deixou de ser seguido."
            });
        }
    );
};

// Listar seguidores
exports.listarSeguidores = (req, res) => {
    const usuarioId = Number(req.params.id);

    if (!usuarioId) {
        return res.status(400).json({
            mensagem: "Usuário inválido."
        });
    }

    seguidorModel.listarSeguidores(
        usuarioId,
        (err, resultados) => {
            if (err) {
                console.error(
                    "Erro ao listar seguidores:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao listar seguidores."
                });
            }

            return res.status(200).json(
                resultados || []
            );
        }
    );
};

// Listar seguindo
exports.listarSeguindo = (req, res) => {
    const usuarioId = Number(req.params.id);

    if (!usuarioId) {
        return res.status(400).json({
            mensagem: "Usuário inválido."
        });
    }

    seguidorModel.listarSeguindo(
        usuarioId,
        (err, resultados) => {
            if (err) {
                console.error(
                    "Erro ao listar seguindo:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao listar seguindo."
                });
            }

            return res.status(200).json(
                resultados || []
            );
        }
    );
};