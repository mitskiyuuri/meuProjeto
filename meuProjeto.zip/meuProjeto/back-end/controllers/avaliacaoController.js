const avaliacaoModel = require("../models/avaliacaoModel");

// Criar avaliação
exports.criar = (req, res) => {
    const avaliadorId = req.usuario.id;
    const avaliadoId = req.body.avaliado_id;
    const nota = Number(req.body.nota);
    const comentario = String(req.body.comentario || "").trim();

    if (!avaliadoId || !nota || !comentario) {
        return res.status(400).json({
            mensagem: "Informe o usuário, a nota e o comentário."
        });
    }

    if (nota < 1 || nota > 5 || !Number.isInteger(nota)) {
        return res.status(400).json({
            mensagem: "A nota deve ser um número inteiro entre 1 e 5."
        });
    }

    if (Number(avaliadoId) === Number(avaliadorId)) {
        return res.status(400).json({
            mensagem: "Você não pode avaliar a si mesmo."
        });
    }

    avaliacaoModel.buscarUsuario(avaliadoId, (err, usuarios) => {
        if (err) {
            console.error("Erro ao buscar usuário:", err);
            return res.status(500).json({
                mensagem: "Erro ao buscar usuário."
            });
        }

        if (!usuarios || usuarios.length === 0) {
            return res.status(404).json({
                mensagem: "Usuário avaliado não encontrado."
            });
        }

        avaliacaoModel.verificarAvaliacao(
            avaliadorId,
            avaliadoId,
            (err, avaliacaoExistente) => {
                if (err) {
                    console.error("Erro ao verificar avaliação:", err);
                    return res.status(500).json({
                        mensagem: "Erro ao verificar avaliação."
                    });
                }

                if (avaliacaoExistente && avaliacaoExistente.length > 0) {
                    return res.status(400).json({
                        mensagem: "Você já avaliou este usuário."
                    });
                }

                const avaliacao = {
                    avaliador_id: avaliadorId,
                    avaliado_id: avaliadoId,
                    nota,
                    comentario
                };

                avaliacaoModel.criar(
                    avaliacao,
                    (err, result) => {
                        if (err) {
                            console.error("Erro ao criar avaliação:", err);
                            return res.status(500).json({
                                mensagem: "Erro ao criar avaliação."
                            });
                        }

                        return res.status(201).json({
                            mensagem: "Avaliação enviada com sucesso!",
                            id: result.insertId
                        });
                    }
                );
            }
        );
    });
};

// Listar avaliações recebidas
exports.listarPorUsuario = (req, res) => {
    avaliacaoModel.listarPorUsuario(
        req.params.id,
        (err, resultados) => {
            if (err) {
                console.error("Erro ao listar avaliações:", err);
                return res.status(500).json({
                    mensagem: "Erro ao listar avaliações."
                });
            }

            return res.status(200).json(resultados || []);
        }
    );
};