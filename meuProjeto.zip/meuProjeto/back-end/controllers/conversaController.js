const conversaModel = require("../models/conversaModel");

// Criar conversa a partir de uma solicitação aceita
exports.criarConversa = (req, res) => {
    const solicitacaoId = req.params.id;
    const usuarioId = req.usuario.id;

    conversaModel.buscarSolicitacao(
        solicitacaoId,
        usuarioId,
        (err, solicitacoes) => {
            if (err) {
                console.error(
                    "Erro ao buscar solicitação:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao buscar solicitação."
                });
            }

            if (
                !solicitacoes ||
                solicitacoes.length === 0
            ) {
                return res.status(404).json({
                    mensagem:
                        "Solicitação não encontrada ou você não participa dela."
                });
            }

            const solicitacao =
                solicitacoes[0];

            if (
                solicitacao.status !==
                "aceita"
            ) {
                return res.status(400).json({
                    mensagem:
                        "A conversa só pode ser criada após a solicitação ser aceita."
                });
            }

            const itemId =
                solicitacao.item_id;

            const doadorId =
                solicitacao.doador_id;

            const interessadoId =
                solicitacao.interessado_id;

            conversaModel.buscarConversa(
                itemId,
                doadorId,
                interessadoId,
                (err, conversas) => {
                    if (err) {
                        console.error(
                            "Erro ao verificar conversa:",
                            err
                        );

                        return res.status(500).json({
                            mensagem:
                                "Erro ao verificar conversa."
                        });
                    }

                    if (
                        conversas &&
                        conversas.length > 0
                    ) {
                        return res.status(200).json({
                            mensagem:
                                "Conversa já existe.",
                            conversaId:
                                conversas[0].id
                        });
                    }

                    conversaModel.criarConversa(
                        itemId,
                        doadorId,
                        interessadoId,
                        (err, result) => {
                            if (err) {
                                console.error(
                                    "Erro ao criar conversa:",
                                    err
                                );

                                return res.status(500).json({
                                    mensagem:
                                        "Erro ao criar conversa."
                                });
                            }

                            return res.status(201).json({
                                mensagem:
                                    "Conversa criada com sucesso!",
                                conversaId:
                                    result.insertId
                            });
                        }
                    );
                }
            );
        }
    );
};

// Listar minhas conversas
exports.listarMinhasConversas = (
    req,
    res
) => {
    conversaModel.listarMinhasConversas(
        req.usuario.id,
        (err, conversas) => {
            if (err) {
                console.error(
                    "Erro ao listar conversas:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao listar conversas."
                });
            }

            return res.status(200).json(
                conversas || []
            );
        }
    );
};