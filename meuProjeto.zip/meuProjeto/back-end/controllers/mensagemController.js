const mensagemModel = require("../models/mensagemModel");

// Enviar mensagem
exports.enviarMensagem = (req, res) => {
    const conversaId = req.params.id;
    const usuarioId = req.usuario.id;
    const mensagem = String(req.body.mensagem || "").trim();

    if (!mensagem) {
        return res.status(400).json({
            mensagem: "A mensagem não pode estar vazia."
        });
    }

    mensagemModel.verificarParticipante(
        conversaId,
        usuarioId,
        (err, conversas) => {
            if (err) {
                console.error("Erro ao verificar conversa:", err);
                return res.status(500).json({
                    mensagem: "Erro ao verificar conversa."
                });
            }

            if (!conversas || conversas.length === 0) {
                return res.status(404).json({
                    mensagem: "Conversa não encontrada ou você não participa dela."
                });
            }

            mensagemModel.criarMensagem(
                conversaId,
                usuarioId,
                mensagem,
                (err, result) => {
                    if (err) {
                        console.error("Erro ao criar mensagem:", err);
                        return res.status(500).json({
                            mensagem: "Erro ao enviar mensagem."
                        });
                    }

                    // Envia a nova mensagem em tempo real
                    const io = req.app.get("io");

                    if (io) {
                        io.to(`conversa_${conversaId}`).emit("nova_mensagem", {
                            id: result.insertId,
                            conversa_id: Number(conversaId),
                            remetente_id: usuarioId,
                            mensagem: mensagem
                        });
                    }

                    return res.status(201).json({
                        mensagem: "Mensagem enviada com sucesso!",
                        id: result.insertId
                    });
                }
            );
        }
    );
};

// Listar histórico
exports.listarMensagens = (req, res) => {
    const conversaId = req.params.id;
    const usuarioId = req.usuario.id;

    mensagemModel.verificarParticipante(
        conversaId,
        usuarioId,
        (err, conversas) => {
            if (err) {
                console.error("Erro ao verificar conversa:", err);
                return res.status(500).json({
                    mensagem: "Erro ao verificar conversa."
                });
            }

            if (!conversas || conversas.length === 0) {
                return res.status(404).json({
                    mensagem: "Conversa não encontrada ou você não participa dela."
                });
            }

            mensagemModel.listarMensagens(
                conversaId,
                (err, mensagens) => {
                    if (err) {
                        console.error("Erro ao listar mensagens:", err);
                        return res.status(500).json({
                            mensagem: "Erro ao listar mensagens."
                        });
                    }

                    return res.status(200).json(mensagens || []);
                }
            );
        }
    );
};

// Marcar mensagens como lidas
exports.marcarComoLidas = (req, res) => {
    const conversaId = req.params.id;
    const usuarioId = req.usuario.id;

    mensagemModel.verificarParticipante(
        conversaId,
        usuarioId,
        (err, conversas) => {
            if (err) {
                console.error("Erro ao verificar conversa:", err);
                return res.status(500).json({
                    mensagem: "Erro ao verificar conversa."
                });
            }

            if (!conversas || conversas.length === 0) {
                return res.status(404).json({
                    mensagem: "Conversa não encontrada ou você não participa dela."
                });
            }

            mensagemModel.marcarComoLidas(
                conversaId,
                usuarioId,
                (err) => {
                    if (err) {
                        console.error("Erro ao marcar mensagens como lidas:", err);
                        return res.status(500).json({
                            mensagem: "Erro ao marcar mensagens como lidas."
                        });
                    }

                    return res.status(200).json({
                        mensagem: "Mensagens marcadas como lidas."
                    });
                }
            );
        }
    );
};