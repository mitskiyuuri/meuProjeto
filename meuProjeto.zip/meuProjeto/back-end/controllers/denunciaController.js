const denunciaModel = require("../models/denunciaModel");

const tiposValidos = [
    "produto diferente do anuncio",
    "produto inexistente",
    "violação de dados",
    "pratica de coerção"
];

const referenciasValidas = [
    "usuario",
    "item",
    "comentario"
];

// Criar denúncia
exports.criar = (req, res) => {
    const usuarioId = req.usuario.id;
    const tipo = req.body.tipo;
    const tipoReferencia = req.body.tipo_referencia;
    const referenciaId = req.body.referencia_id;
    const motivo = String(req.body.motivo || "").trim();

    if (!tiposValidos.includes(tipo)) {
        return res.status(400).json({
            mensagem: "Tipo de denúncia inválido."
        });
    }

    if (!referenciasValidas.includes(tipoReferencia)) {
        return res.status(400).json({
            mensagem: "Tipo de referência inválido. Use usuario, item ou comentario."
        });
    }

    if (!referenciaId || !motivo) {
        return res.status(400).json({
            mensagem: "Informe o alvo da denúncia e o motivo."
        });
    }

    function criarDenuncia() {
        const denuncia = {
            usuario_id: usuarioId,
            tipo,
            tipo_referencia: tipoReferencia,
            referencia_id: referenciaId,
            motivo
        };

        denunciaModel.criar(denuncia, (err, result) => {
            if (err) {
                console.error("Erro ao criar denúncia:", err);
                return res.status(500).json({
                    mensagem: "Erro ao registrar denúncia."
                });
            }

            return res.status(201).json({
                mensagem: "Denúncia registrada com sucesso!",
                id: result.insertId
            });
        });
    }

    if (tipoReferencia === "usuario") {
        denunciaModel.verificarUsuario(
            referenciaId,
            (err, resultados) => {
                if (err) {
                    console.error("Erro ao verificar usuário:", err);
                    return res.status(500).json({
                        mensagem: "Erro ao verificar usuário."
                    });
                }

                if (!resultados || resultados.length === 0) {
                    return res.status(404).json({
                        mensagem: "Usuário não encontrado."
                    });
                }

                criarDenuncia();
            }
        );

        return;
    }

    if (tipoReferencia === "item") {
        denunciaModel.verificarItem(
            referenciaId,
            (err, resultados) => {
                if (err) {
                    console.error("Erro ao verificar item:", err);
                    return res.status(500).json({
                        mensagem: "Erro ao verificar item."
                    });
                }

                if (!resultados || resultados.length === 0) {
                    return res.status(404).json({
                        mensagem: "Item não encontrado."
                    });
                }

                criarDenuncia();
            }
        );

        return;
    }

    denunciaModel.verificarComentario(
        referenciaId,
        (err, resultados) => {
            if (err) {
                console.error("Erro ao verificar comentário:", err);
                return res.status(500).json({
                    mensagem: "Erro ao verificar comentário."
                });
            }

            if (!resultados || resultados.length === 0) {
                return res.status(404).json({
                    mensagem: "Comentário não encontrado."
                });
            }

            criarDenuncia();
        }
    );
};