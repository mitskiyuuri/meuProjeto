const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const userModel = require("../models/userModel");

// ==========================================
// 1. CADASTRO
// ==========================================

exports.cadastrarUsuario = async (req, res) => {
    try {
        const {
            nome,
            email,
            telefone,
            cpf,
            senha,
            cep,
            cidade,
            estado,
            bairro,
            endereco,
            numero,
            complemento
        } = req.body;

        if (
            !nome ||
            !email ||
            !cpf ||
            !senha ||
            !cep ||
            !cidade ||
            !estado ||
            !bairro ||
            !endereco ||
            !numero
        ) {
            return res.status(400).json({
                mensagem:
                    "Preencha todos os campos obrigatórios."
            });
        }

        userModel.buscarPorEmailOuCpf(
            email,
            cpf,
            async (err, results) => {

                if (err) {
                    console.error(
                        "Erro ao buscar e-mail/cpf:",
                        err
                    );

                    return res.status(500).json({
                        mensagem:
                            "Erro ao verificar usuário."
                    });
                }

                if (
                    results &&
                    results.length > 0
                ) {
                    return res.status(400).json({
                        mensagem:
                            "E-mail ou CPF já cadastrado."
                    });
                }

                const senhaCriptografada =
                    await bcrypt.hash(
                        senha,
                        10
                    );

                const usuario = {
                    nome: nome.trim(),
                    email: email.trim(),
                    telefone: telefone
                        ? telefone.trim()
                        : "",
                    cpf: cpf.trim(),
                    senha: senhaCriptografada,
                    cep: cep.trim(),
                    cidade: cidade.trim(),
                    estado: String(estado)
                        .trim()
                        .toUpperCase(),
                    bairro: bairro.trim(),
                    endereco: endereco.trim(),
                    numero: numero.trim(),
                    complemento:
                        complemento
                            ? complemento.trim()
                            : "",
                    foto_perfil: null,
                    foto_documento: null
                };

                userModel.criarUsuario(
                    usuario,
                    (err) => {

                        if (err) {
                            console.error(
                                "Erro ao criar usuário:",
                                err
                            );

                            return res.status(500).json({
                                mensagem:
                                    "Erro ao criar usuário."
                            });
                        }

                        return res.status(201).json({
                            mensagem:
                                "Usuário criado com sucesso!"
                        });
                    }
                );
            }
        );

    } catch (erro) {
        console.error(
            "Erro interno no cadastro:",
            erro
        );

        return res.status(500).json({
            mensagem:
                "Erro interno do servidor."
        });
    }
};

// ==========================================
// 2. LOGIN
// ==========================================

exports.loginUsuario = (
    req,
    res
) => {

    const {
        email,
        senha
    } = req.body;

    if (!email || !senha) {
        return res.status(400).json({
            mensagem:
                "Informe e-mail e senha."
        });
    }

    userModel.buscarPorEmail(
        email.trim(),
        async (err, results) => {

            if (err) {
                console.error(
                    "Erro na busca de e-mail:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao buscar usuário."
                });
            }

            if (
                !results ||
                results.length === 0
            ) {
                return res.status(401).json({
                    mensagem:
                        "E-mail ou senha inválidos."
                });
            }

            const usuario = results[0];

            const senhaCorreta =
                await bcrypt.compare(
                    senha,
                    usuario.senha
                );

            if (!senhaCorreta) {
                return res.status(401).json({
                    mensagem:
                        "E-mail ou senha inválidos."
                });
            }

            const secretKey =
                process.env.JWT_SECRET;

            if (!secretKey) {
                console.error(
                    "JWT_SECRET não foi configurado no arquivo .env"
                );

                return res.status(500).json({
                    mensagem:
                        "Configuração de segurança do servidor não encontrada."
                });
            }

            const token = jwt.sign(
                {
                    id: usuario.id,
                    email: usuario.email
                },
                secretKey,
                {
                    expiresIn: "7d"
                }
            );

            return res.status(200).json({
                mensagem:
                    "Login realizado com sucesso!",

                token,

                usuario: {
                    id: usuario.id,
                    nome: usuario.nome,
                    email: usuario.email,
                    cidade: usuario.cidade,
                    bairro: usuario.bairro
                }
            });
        }
    );
};

// ==========================================
// 3. RECUPERAÇÃO DE SENHA
// ==========================================

exports.solicitarRecuperacao = (
    req,
    res
) => {

    const email = String(
        req.body.email || ""
    ).trim();

    if (!email) {
        return res.status(400).json({
            mensagem:
                "Informe o e-mail."
        });
    }

    userModel.buscarUsuarioParaRecuperacao(
        email,
        (err, usuarios) => {

            if (err) {
                console.error(
                    "Erro ao buscar usuário para recuperação:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao solicitar recuperação."
                });
            }

            if (
                !usuarios ||
                usuarios.length === 0
            ) {
                return res.status(404).json({
                    mensagem:
                        "E-mail não encontrado."
                });
            }

            const usuario = usuarios[0];

            const codigo = crypto
                .randomInt(
                    100000,
                    1000000
                )
                .toString();

            const codigoHash =
                crypto
                    .createHash("sha256")
                    .update(codigo)
                    .digest("hex");

            userModel.criarRecuperacao(
                usuario.id,
                codigoHash,
                (err) => {

                    if (err) {
                        console.error(
                            "Erro ao criar recuperação:",
                            err
                        );

                        return res.status(500).json({
                            mensagem:
                                "Erro ao gerar código de recuperação."
                        });
                    }

                    return res.status(200).json({
                        mensagem:
                            "Código de recuperação gerado com sucesso.",
                        codigo
                    });
                }
            );
        }
    );
};

exports.redefinirSenha = async (
    req,
    res
) => {

    try {

        const email = String(
            req.body.email || ""
        ).trim();

        const codigo = String(
            req.body.codigo || ""
        ).trim();

        const novaSenha = String(
            req.body.nova_senha || ""
        );

        if (
            !email ||
            !codigo ||
            !novaSenha
        ) {
            return res.status(400).json({
                mensagem:
                    "Informe e-mail, código e nova senha."
            });
        }

        if (!/^\d{6}$/.test(codigo)) {
            return res.status(400).json({
                mensagem:
                    "O código deve ter 6 números."
            });
        }

        if (novaSenha.length < 6) {
            return res.status(400).json({
                mensagem:
                    "A nova senha deve ter pelo menos 6 caracteres."
            });
        }

        userModel.buscarUsuarioParaRecuperacao(
            email,
            async (err, usuarios) => {

                if (err) {
                    console.error(
                        "Erro ao buscar usuário:",
                        err
                    );

                    return res.status(500).json({
                        mensagem:
                            "Erro ao recuperar senha."
                    });
                }

                if (
                    !usuarios ||
                    usuarios.length === 0
                ) {
                    return res.status(404).json({
                        mensagem:
                            "E-mail não encontrado."
                    });
                }

                const usuario =
                    usuarios[0];

                const codigoHash =
                    crypto
                        .createHash("sha256")
                        .update(codigo)
                        .digest("hex");

                userModel.buscarRecuperacao(
                    usuario.id,
                    codigoHash,
                    async (
                        err,
                        recuperacoes
                    ) => {

                        if (err) {
                            console.error(
                                "Erro ao verificar código:",
                                err
                            );

                            return res.status(500).json({
                                mensagem:
                                    "Erro ao verificar código."
                            });
                        }

                        if (
                            !recuperacoes ||
                            recuperacoes.length === 0
                        ) {
                            return res.status(400).json({
                                mensagem:
                                    "Código inválido ou expirado."
                            });
                        }

                        const senhaCriptografada =
                            await bcrypt.hash(
                                novaSenha,
                                10
                            );

                        userModel.atualizarSenha(
                            usuario.id,
                            senhaCriptografada,
                            (err) => {

                                if (err) {
                                    console.error(
                                        "Erro ao atualizar senha:",
                                        err
                                    );

                                    return res.status(500).json({
                                        mensagem:
                                            "Erro ao redefinir senha."
                                    });
                                }

                                userModel.marcarRecuperacaoComoUsada(
                                    recuperacoes[0].id,
                                    (err) => {

                                        if (err) {
                                            console.error(
                                                "Erro ao finalizar recuperação:",
                                                err
                                            );

                                            return res.status(500).json({
                                                mensagem:
                                                    "Senha alterada, mas houve um erro ao finalizar o código."
                                            });
                                        }

                                        return res.status(200).json({
                                            mensagem:
                                                "Senha redefinida com sucesso!"
                                        });
                                    }
                                );
                            }
                        );
                    }
                );
            }
        );

    } catch (erro) {

        console.error(
            "Erro interno na recuperação:",
            erro
        );

        return res.status(500).json({
            mensagem:
                "Erro interno do servidor."
        });
    }
};

// ==========================================
// 4. BUSCAR PERFIL
// ==========================================

exports.buscarPerfil = (
    req,
    res
) => {

    userModel.buscarPorId(
        req.usuario.id,
        (err, results) => {

            if (err) {
                console.error(
                    "Erro ao buscar perfil:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao buscar perfil."
                });
            }

            if (
                !results ||
                results.length === 0
            ) {
                return res.status(404).json({
                    mensagem:
                        "Usuário não encontrado."
                });
            }

            const usuario = {
                ...results[0]
            };

            delete usuario.senha;

            userModel.buscarMediaAvaliacoes(
                req.usuario.id,
                (err, resumo) => {

                    if (err) {
                        console.error(
                            "Erro ao buscar média das avaliações:",
                            err
                        );

                        return res.status(500).json({
                            mensagem:
                                "Erro ao buscar avaliações."
                        });
                    }

                    usuario.media_avaliacoes =
                        resumo &&
                        resumo.length > 0
                            ? Number(
                                resumo[0]
                                    .media_avaliacoes
                            )
                            : 0;

                    usuario.total_avaliacoes =
                        resumo &&
                        resumo.length > 0
                            ? Number(
                                resumo[0]
                                    .total_avaliacoes
                            )
                            : 0;

                    return res.status(200).json(
                        usuario
                    );
                }
            );
        }
    );
};

// ==========================================
// 5. ATUALIZAR PERFIL
// ==========================================

exports.atualizarPerfil = (
    req,
    res
) => {

    const nome = String(
        req.body.nome || ""
    ).trim();

    const telefone = String(
        req.body.telefone || ""
    ).trim();

    const cep = String(
        req.body.cep || ""
    ).trim();

    const cidade = String(
        req.body.cidade || ""
    ).trim();

    const estado = String(
        req.body.estado || ""
    ).trim()
        .toUpperCase();

    const bairro = String(
        req.body.bairro || ""
    ).trim();

    const endereco = String(
        req.body.endereco || ""
    ).trim();

    const numero = String(
        req.body.numero || ""
    ).trim();

    const complemento = String(
        req.body.complemento || ""
    ).trim();

    if (
        !nome ||
        !cep ||
        !cidade ||
        !estado ||
        !bairro ||
        !endereco ||
        !numero
    ) {
        return res.status(400).json({
            mensagem:
                "Preencha todos os campos obrigatórios do perfil."
        });
    }

    if (nome.length < 3) {
        return res.status(400).json({
            mensagem:
                "O nome deve ter pelo menos 3 caracteres."
        });
    }

    if (!/^[A-Z]{2}$/.test(estado)) {
        return res.status(400).json({
            mensagem:
                "O estado deve ser informado com 2 letras."
        });
    }

    if (!/^\d{5}-?\d{3}$/.test(cep)) {
        return res.status(400).json({
            mensagem:
                "Informe um CEP válido."
        });
    }

    const usuario = {
        id: req.usuario.id,
        nome,
        telefone,
        cep,
        cidade,
        estado,
        bairro,
        endereco,
        numero,
        complemento
    };

    userModel.atualizarUsuario(
        usuario,
        (err, result) => {

            if (err) {
                console.error(
                    "Erro ao atualizar perfil:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao atualizar perfil."
                });
            }

            if (
                !result ||
                result.affectedRows === 0
            ) {
                return res.status(404).json({
                    mensagem:
                        "Usuário não encontrado ou nenhum dado foi alterado."
                });
            }

            return res.status(200).json({
                mensagem:
                    "Perfil atualizado com sucesso!"
            });
        }
    );
};

// ==========================================
// 6. EXCLUIR PERFIL
// ==========================================

exports.excluirPerfil = (
    req,
    res
) => {

    userModel.excluirUsuario(
        req.usuario.id,
        (err, result) => {

            if (err) {
                console.error(
                    "Erro ao excluir perfil:",
                    err
                );

                return res.status(500).json({
                    mensagem:
                        "Erro ao excluir perfil."
                });
            }

            if (
                !result ||
                result.affectedRows === 0
            ) {
                return res.status(404).json({
                    mensagem:
                        "Usuário não encontrado."
                });
            }

            return res.status(200).json({
                mensagem:
                    "Perfil excluído com sucesso!"
            });
        }
    );
};